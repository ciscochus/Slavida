#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
"""
@author: Sergio Pino y Adam Mora
"""

class Observable():
    '''Definici�n gen�rica de una observable'''
    def __init__(self,nombre=None,tipo=None,valoresPermitidos=None,valor=None):
        #print 'observable->',valor
        self.nombre=nombre
        self.valor=valor
        self.tipo=tipo
        self.valoresPermitidos=valoresPermitidos

class Fiebre(Observable):
    def __init__(self,valor=None):
        nombre='Fiebre'
        tipo='multiple'
        valoresPermitidos=['Normal','Alta','Muy Alta']
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class DolorOrinar(Observable):
    def __init__(self,valor=None):
        nombre='Dolor al orinar'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class SecrecionUretral(Observable):
    def __init__(self,valor=None):
        nombre='Secrecion uretral'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class Picores(Observable):
    def __init__(self,valor=None):
        nombre='Picores'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class Diarrea(Observable):
    def __init__(self,valor=None):
        nombre='Diarrea'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class Vomito(Observable):
    def __init__(self,valor=None):
        nombre='Vomito'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class Ulceras(Observable):
    def __init__(self,valor=None):
        nombre='Ulceras'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor
        
class Depresion(Observable):
    def __init__(self,valor=None):
        nombre='Depresion'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor

class PerdidaCabello(Observable):
    def __init__(self,valor=None):
        nombre='Perdida de cabello'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor
 
class Infertilidad(Observable):
    def __init__(self,valor=None):
        nombre='Infertilidad'
        tipo='boleano'
        valoresPermitidos=None
        Observable.__init__(self,nombre ,tipo ,valoresPermitidos,valor)
        self.valor=valor
      
        
def observables():
    '''Devuelve la lista de observables de la BC
    '''
    obs=[]
    obs.append(Fiebre())
    obs.append(DolorOrinar())
    obs.append(SecrecionUretral())
    obs.append(Picores())
    obs.append(Diarrea())
    obs.append(Vomito())
    obs.append(Ulceras())
    obs.append(Depresion())
    obs.append(PerdidaCabello())
    obs.append(Infertilidad())
    return obs

def creaObservable(tp):
    '''Crea una instancia de un observable si la tupla coincide con la base de conocimiento
    . Si la observable es correcta devuelve una instancia de la observable.
    Corregir. Hay que mejorar esta funci�n'''
    
    print tp
    if tp[0]==u'Fiebre':
        ob=Fiebre(tp[1])
        return ob
    elif tp[0]==u'Dolor al orinar':
        ob=DolorOrinar(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Secrecion uretral':
        ob=SecrecionUretral(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Picores':
        ob=Picores(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Diarrea':
        ob=Diarrea(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Vomito':
        ob=Vomito(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Ulceras':
        ob=Ulceras(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Depresion':
        ob=Depresion(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Perdida de cabello':
        ob=PerdidaCabello(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    elif tp[0]==u'Infertilidad':
        ob=Infertilidad(tp[1])
        if tp[1]=='True':
            ob.valor=True
        return ob
    return None
        
    
    

class Enfermedad():
    '''Clase Enfermedad
    '''
    def __init__(self,nombre):
        self.nombre=nombre
        self.ayuda=u''

class Gonorrea(Enfermedad):
    def __init__(self):
        Enfermedad.__init__(self,nombre=u'Gonorrea'.encode(encoding='iso-8859-1'))
        #Creamos instancias de observables
        orinar=DolorOrinar(True)
        securetral=SecrecionUretral(True)
        infertil=Infertilidad(False)
        ulcera=Ulceras(True)
        #Creamos instancias de observables
        self.debePresentar =[orinar,securetral]
        self.noPuedePresentar = [infertil,ulcera]
        self.ayuda=u'Ayuda sobre la gonorrea'.encode(encoding='iso-8859-1')


class Sifilis(Enfermedad):
    def __init__(self):
        Enfermedad.__init__(self,nombre=u'Sifilis'.encode(encoding='iso-8859-1'))
        #Creamos instancias de observables
        fiebreAlta=Fiebre([u'Normal',u'Alta',u'Muy Alta'])
        pcabello=PerdidaCabello(True)
        ulcera=Ulceras(True)
        infertil=Infertilidad(False)
        cab=PerdidaCabello(True)
        self.debePresentar =[ulcera,cab]
        self.puedePresentar = [fiebreAlta,pcabello]
        self.noPuedePresentar = [infertil]
        self.ayuda=u'Ayuda sobre s�filis'.encode(encoding='iso-8859-1')

class Vih(Enfermedad):
    def __init__(self):
        Enfermedad.__init__(self,nombre=u'VIH'.encode(encoding='iso-8859-1'))
        #Creamos instancias de observables
        fiebreAlta=Fiebre([u'Normal',u'Alta',u'Muy Alta'])
        orinar=DolorOrinar(True)
        inf=Infertilidad(True)
        vom=Vomito(True)
        dia=Diarrea(True)
        dep=Depresion(True)
        self.debePresentar =[fiebreAlta,inf,vom,dia]
        self.puedePresentar = [dep]
        self.noPuedePresentar = [orinar]
        self.ayuda=u'Ayuda sobre el VIH'.encode(encoding='iso-8859-1')

class HerpesGenital(Enfermedad):
    def __init__(self):
        Enfermedad.__init__(self,nombre=u'Herpes genital'.encode(encoding='iso-8859-1'))
        #Creamos instancias de observables
        fiebreAlta=Fiebre([u'Normal',u'Alta',u'Muy Alta'])
        ulc=Ulceras(True)
        pic=Picores(True)
        inf=Infertilidad(True)
        self.debePresentar =[fiebreAlta,ulc,pic]
        self.noPuedePresentar = [inf]
        self.ayuda=u'Ayuda sobre el herpes genital'.encode(encoding='iso-8859-1')

def hipotesis():
    '''
    Posibles enfermedades o aver�as que pueden darse
    '''
    h1=Gonorrea()
    h2=Sifilis()
    h3=Vih()
    h4=HerpesGenital()
    lHp=[h1,h2,h3,h4]
    return lHp

if __name__ == '__main__':
    if False:
        e=Gonorrea()
        for s in e.debePresentar:
            print s.nombre, s.valor
        print e.ayuda
    if False:
        f=Fiebre('Alta')
        print f.nombre
        print f.valor
        f.valor='Baja'
        print f.valor
        print f.valoresPermitidos
    if False:
        for o in observables():
            print o.nombre,o.tipo,o.valoresPermitidos

    if False:
        c=creaObservable(('Dolor al orinar','Secrecion uretral'))
        if not c==None:
            
            print c.nombre
            print c.valor
            print c.tipo
            print c.valoresPermitidos
            
        else:
            print 'error'
    if False:
        cr=Sifilis()
        print cr.debePresentar
        print cr.puedePresentar
    if False:
        #hs=hipotesis()
        #print hs[2].debePresentar[0].valor
        dl=Infertilidad(valor=['True','False'])
        print dl.valor
    if True:
        hipotesis= hipotesis()
        
        
        
    pass
