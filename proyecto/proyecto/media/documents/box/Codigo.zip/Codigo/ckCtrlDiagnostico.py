#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
"""
@author: Sergio Pino y Adam Mora
"""
from PySide import QtGui
from PySide import QtCore
import ckModApDiagnostico
#import vDiagnostico

def eventCoberturaCausal(cdDiagnostico,tr=False):
    '''
    Inferenvia de cobretura causal.
    '''
    fallos=[]#Vamos a captar los fallos del cuadro de di�logo
    if tr:
        print 'entra'
    for i in range(cdDiagnostico.tableWidgetPosiblesFallos.rowCount()):
        item1=cdDiagnostico.tableWidgetPosiblesFallos.item(i,0)
        if item1.checkState()==QtCore.Qt.CheckState.Checked:
            #print item1.checkState()
            item2=cdDiagnostico.tableWidgetPosiblesFallos.cellWidget(i, 1)
            #print item2, item2.currentText()
            fallos.append( (item1.text(),item2.currentText()) )
    if tr:
        print fallos
    cc=ckModApDiagnostico.CoberturaCausal(fallos)#Invocamos a la inferencia de cobertura causal del diagn�stico
    cc.execute()
    lHipotesis=[]
    for h in cc.listaHipotesis:
        lHipotesis.append(h.nombre)#Obtenemos la lista de hip�tesis
    cdDiagnostico.listWidgetHipotesis.clear()#Borramos la informaci�n del listWidget
    cdDiagnostico.listWidgetHipotesis.addItems(lHipotesis)#a�adimos la nueva informaci�n al listWidgwet
    
            
def eventDiagnostica(cdDiagnostico,tr=False):
    '''
    Controla el evendo de diagn�stico
    '''
    cdDiagnostico.PlainTextEditExplicacion.clear()
    pass
    eventCoberturaCausal(cdDiagnostico,tr=False)
    fallos=[]
        #print cdDiagnostico.listWidgetFallos.count()
    if tr:
        print 'entra'
    for i in range(cdDiagnostico.tableWidgetPosiblesFallos.rowCount()):
        item1=cdDiagnostico.tableWidgetPosiblesFallos.item(i,0)
        if item1.checkState()==QtCore.Qt.CheckState.Checked:
            #print item1.checkState()
            item2=cdDiagnostico.tableWidgetPosiblesFallos.cellWidget(i, 1)
            #print item2, item2.currentText()
            fallos.append( (item1.text(),item2.currentText()) )#Creamos una tupla del fallo y sus posibles
                                                               #valores
    if tr:        
        print 'Presentando los fallos',fallos
        print '======================'
    
    #Comprueba que los fallos captados son compatibles con la base de conocimiento
    observables=ckModApDiagnostico.identificaSignosSintomas(fallos)
    if tr:
        print 'Obteniendo Observables:', observables
    if not observables==None:#Continuo porque todo es correcto
        pass
        mcc=ckModApDiagnostico.MetodoCoberturaCausal(observables)#Creamos una instancia del m�todo cc
        mcc.execute()
        if tr:
            pass
        print 'Justificaci�n'
        print '============='
        print mcc.explicacion
        print 
        print 'Diagn�stico: ' 
        print '============ '
        for d in mcc.diagnostico:
            print d.nombre
        print 'fin'
        cdDiagnostico.PlainTextEditExplicacion.clear()
        cdDiagnostico.PlainTextEditExplicacion.appendPlainText(mcc.explicacion)
        cdDiagnostico.PlainTextEditExplicacion.moveCursor(QtGui.QTextCursor.Start)
        
        
        #tc=cdDiagnostico.PlainTextEditExplicacion.textCursor()
        #tc.movePosition(QtGui.QTextCursor.Start)
        #print tc.position()
        cdDiagnostico.listWidgetDiagnosticos.clear()
        lDiag=[]
        for d in mcc.diagnostico:
            lDiag.append(d.nombre)
            cdDiagnostico.listWidgetDiagnosticos.addItems(lDiag)
    
    
        
        
    
    return
    mcc=ckModApDiagnostico.MetodoCoberturaCausal(fallos)
    mcc.execute()
    print mcc.diagnostico
    print mcc.explicacion
    
    
 
def observables():
    return 
       
    

if __name__=='__main__':  
    pass

            
        
        