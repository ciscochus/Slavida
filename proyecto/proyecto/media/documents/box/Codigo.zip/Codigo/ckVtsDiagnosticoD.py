#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
"""
@author: Sergio Pino y Adam Mora
"""


import sys
from PySide import QtCore
from PySide import QtGui
import ckCtrlDiagnostico

class DiagnosticDlg(QtGui.QWidget):
    '''
    Cuadro de dial�go para la tarea de diang�stico
    '''
    def __init__(self, name, observables=None, parent=None):
        '''
        Inicio del cuadro de di�logo
        
        @param name: Nombre del cuadro
        @type name: string
        
        @param observables: Posibles observables
        @type obsevables: tupla de dos valores 
        
        '''
        super(DiagnosticDlg, self).__init__(parent)

        self.name = name #Coloca el nombre al cuadro de di�logo
        #Label
        labelListA=QtGui.QLabel("Selecione los sintomas presentados",self)
        labelListB=QtGui.QLabel("",self)#quitar
        observables_list = [(f.nombre , f.valor)  for f in observables]
        header = ['NOMBRE', 'VALOR']
        #posiblesFallos = Fallos(self,   observables_list, header)
        self.tableWidgetPosiblesFallos = QtGui.QTableWidget(len(observables_list),2) #Crea la tabla de elementos
        self.tableWidgetPosiblesFallos.setColumnWidth(0, 400) #Asignan ancho a las columnas
        self.tableWidgetPosiblesFallos.setColumnWidth(1, 400)
        self.tableWidgetPosiblesFallos.setHorizontalHeaderLabels(header) #Asigna etiquetas a las columnas
        
        #print observables
        for i in range(len(observables)):
            #print i, observables[i].nombre,observables[i].tipo,observables[i].valoresPermitidos
            item1 = QtGui.QTableWidgetItem(observables[i].nombre) #Crea un item y le asigna el nombre de la observable
            item1.setCheckState(QtCore.Qt.Checked) # Establece propiedades a las celdas de la primera columna
            item1.setFlags(QtCore.Qt.ItemIsUserCheckable|QtCore.Qt.ItemIsEnabled)

            if observables[i].tipo=='multiple':#Si el tipo de observable es m�ltiple creamos un combox
                combobox = QtGui.QComboBox()
                for j in observables[i].valoresPermitidos:#a�adimmos al combox los valeores permitidos
                    combobox.addItem(j) 
                self.tableWidgetPosiblesFallos.setCellWidget(i, 1, combobox)#Establecemos en la celda i el combox
            elif observables[i].tipo=='boleano':#Si es boleano creamos otro combox
                combobox = QtGui.QComboBox()
                combobox.addItem('True') 
                combobox.addItem('False') 
                self.tableWidgetPosiblesFallos.setCellWidget(i, 1, combobox)

            self.tableWidgetPosiblesFallos.setItem(i, 0, item1)#Establecemos el item en la columna 0
                
        labelHipotesisL=QtGui.QLabel("Posibles Hipotesis",self)#Creamos un listwidget para las posibles hip�tesis
        labelHipotesisR=QtGui.QLabel("",self)
        self.listWidgetHipotesis = QtGui.QListWidget()#Lista de hip�tesis
        
        labelDiagnosticoL=QtGui.QLabel("Diagn�stico",self)
        labelDiagnosticoR=QtGui.QLabel("",self)
        self.listWidgetDiagnosticos = QtGui.QListWidget()#Lista de diagn�sticos
        
        labelExplicacionL=QtGui.QLabel("Explicacion",self)
        labelExplicacionR=QtGui.QLabel("     ",self)
        self.PlainTextEditExplicacion = QtGui.QPlainTextEdit()#Cuadro de texto    de la explicaci�n           
        #Botones
        self.coberturaCausalButton=QtGui.QPushButton('Cobertura Causal')#Para invocar el m�todo de cobretura causal
        self.diagnosticaButton=QtGui.QPushButton('Diagnostica') #Para ejecutar el diagn�stico
        self.exitButton=QtGui.QPushButton('Exit') #Para salir del programa
        
        self.buttonsLayout = QtGui.QHBoxLayout() #Gestor de dise�o horizontal
        #http://stackoverflow.com/questions/20452754/how-exactly-does-addstretch-work-in-qboxlayout
        self.buttonsLayout.addStretch()
        self.buttonsLayout.addWidget(self.coberturaCausalButton)
        self.buttonsLayout.addWidget(self.diagnosticaButton)
        self.buttonsLayout.addWidget(self.exitButton)
        self.buttonsLayout.addStretch()
        
        #Rejilla de distribuci�n de los controles
        #Ver http://srinikom.github.io/pyside-docs/PySide/QtGui/QGridLayout.html
        grid = QtGui.QGridLayout()
        grid.setSpacing(5)
        grid.addWidget(labelListA, 0, 0)
        grid.addWidget(self.tableWidgetPosiblesFallos, 1, 0,1,2)
        grid.addWidget(labelListB, 0, 1)
        
        grid.addWidget(labelHipotesisL, 2, 0)
        grid.addWidget(labelHipotesisR, 2, 1)
        grid.addWidget(self.listWidgetHipotesis, 3, 0,1,2)
        
        grid.addWidget(labelDiagnosticoL, 4, 0)
        grid.addWidget(labelDiagnosticoR, 4, 1)
        grid.addWidget(self.listWidgetDiagnosticos, 5, 0,1,2)
        grid.addWidget(labelExplicacionL, 6, 0)
        grid.addWidget(labelExplicacionR, 6, 1)
        grid.addWidget(self.PlainTextEditExplicacion, 7, 0,1,2)
        
        #Dise�o principal
        mainLayout = QtGui.QVBoxLayout()
        mainLayout.addLayout(grid)
        mainLayout.addLayout(self.buttonsLayout)
        self.setLayout(mainLayout) #Asignar a la ventana la distribuci�n de los controles
        
    
        self.setGeometry(300, 300, 900, 1200)
        self.setWindowTitle(u"TAREA DE DIAGNOSTICO DE ETS".format(self.name))
        self.show()
 
        self.center()
        
        #Conexiones de los botones y eventos en las listas:
        #==========
        self.tableWidgetPosiblesFallos.itemDoubleClicked.connect(self.moveRight)
        #self.listWidgetFallos.itemDoubleClicked.connect(self.moveLeft)
        self.coberturaCausalButton.clicked.connect(self.coberturaCausal)
        self.diagnosticaButton.clicked.connect(self.diagnostica)
        self.exitButton.clicked.connect(self.close)


    def dl(self,item):
        print item.text()

    def moveLeft(self):
        '''NO USADO'''
        #Pasa el elemento seleccionado a la izquierda
        #Falta->
        return
        row = self.listWidgetFallos.currentRow()
        item = self.listWidgetFallos.item(row)
        if item is None:
            return
        print item.text()
        self.listWidgetPosiblesFallos.insertItem(0,item.text() )
        self.listWidgetPosiblesFallos.sortItems()
        item = self.listWidgetFallos.takeItem(row)
        del item
        pass

    def moveRight(self):
        '''NO USADO'''
        #Pasa el elemento seleccionado a la derecha
        return
        print self.tableWidgetPosiblesFallos.currentRow()
        row = self.tableWidgetPosiblesFallos.currentRow()
        column = self.tableWidgetPosiblesFallos.currentColumn()
        print row
        item = self.tableWidgetPosiblesFallos.item(row,0)
        if item is None:
            return
        print item.text()
        #Comprobar que no se repitan s�ntomas->Falta
        
        #insert una fila
        self.tableWidgetFallos.insertRow(0)
        newItem1=QtGui.QTableWidgetItem(item.text())
        self.tableWidgetFallos.setItem(0, 0, newItem1)
        newItem1.setFlags(QtCore.Qt.ItemIsSelectable|QtCore.Qt.ItemIsEnabled)
        newItem2=QtGui.QTableWidgetItem('Valor')
        self.tableWidgetFallos.setItem(0, 1, newItem2)
        
        pass
    
    def diagnostica(self):
        ckCtrlDiagnostico.eventDiagnostica(self)
        
        
    def coberturaCausal(self):
        #Recolecta datos de las vistas y se lo pasamos al controlador
        # Al pasar self pasamos toda la informaci�n de la ventana
        ckCtrlDiagnostico.eventCoberturaCausal(self)
    
    def center(self):        
        qr = self.frameGeometry()
        cp = QtGui.QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topRight())



        
if __name__ == "__main__":
    if True:
        #Podemos probar el m�dulo de vistas de forma aut�noma
        observables =  ckCtrlDiagnostico.ckModApDiagnostico.bcETS.observables()
        
        app = QtGui.QApplication(sys.argv)
        form = DiagnosticDlg("Fallos", observables)
        sys.exit(app.exec_())
    if False:
        observables =  ckCtrlDiagnostico.ckModApDiagnostico.bcETS.observables()
        print observables
        l = [(f.nombre , f.valor)  for f in observables]
        print l
        header = ['Nombre', 'Valor']
         
    

 